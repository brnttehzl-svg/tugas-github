# Tugas Maria

Website tugas tabel HTML dan CSS.

File:
- `index.html` — halaman tabel
- `style.css` — navbar dan dropdown
- `table.css` — latar dan desain tabel

Pastikan semua file berada di folder yang sama saat diupload ke GitHub.
